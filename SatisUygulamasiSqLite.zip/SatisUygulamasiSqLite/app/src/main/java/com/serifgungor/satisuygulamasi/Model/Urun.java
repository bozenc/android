package com.serifgungor.satisuygulamasi.Model;

import java.io.Serializable;

public class Urun implements Serializable {
    private int id;
    private int altKategori_id;
    private String baslik;
    private double fiyat;
    private String resim;
    private String Aciklama;

    public Urun() {
    }

    public Urun(int id, int altKategori_id, String baslik, double fiyat, String resim, String aciklama) {
        this.id = id;
        this.altKategori_id = altKategori_id;
        this.baslik = baslik;
        this.fiyat = fiyat;
        this.resim = resim;
        Aciklama = aciklama;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAltKategori_id() {
        return altKategori_id;
    }

    public void setAltKategori_id(int altKategori_id) {
        this.altKategori_id = altKategori_id;
    }

    public String getBaslik() {
        return baslik;
    }

    public void setBaslik(String baslik) {
        this.baslik = baslik;
    }

    public double getFiyat() {
        return fiyat;
    }

    public void setFiyat(double fiyat) {
        this.fiyat = fiyat;
    }

    public String getResim() {
        return resim;
    }

    public void setResim(String resim) {
        this.resim = resim;
    }

    public String getAciklama() {
        return Aciklama;
    }

    public void setAciklama(String aciklama) {
        Aciklama = aciklama;
    }
}
