package com.serifgungor.satisuygulamasi.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.serifgungor.satisuygulamasi.Model.Urun;
import com.serifgungor.satisuygulamasi.R;

import java.util.ArrayList;

public class AdapterUrun extends BaseAdapter {

    private ArrayList<Urun> urunler;
    private Context context;
    private LayoutInflater layoutInflater;

    public AdapterUrun() {
    }

    public AdapterUrun(ArrayList<Urun> urunler, Context context) {
        this.urunler = urunler;
        this.context = context;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }


    @Override
    public int getCount() {
        return urunler.size();
    }

    @Override
    public Object getItem(int i) {
        return urunler.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View v = layoutInflater.inflate(R.layout.urun_satirgoruntusu,null);

        ImageView iv = v.findViewById(R.id.ivUrunResimi);
        TextView tvBaslik = v.findViewById(R.id.tvUrunBaslik);
        TextView tvFiyat = v.findViewById(R.id.tvUrunFiyat);

        tvBaslik.setText(urunler.get(i).getBaslik());
        tvFiyat.setText(""+ urunler.get(i).getFiyat());

        Glide
                .with(context)
                .load(urunler.get(i).getResim())
                .into(iv);


        return v;
    }
}
