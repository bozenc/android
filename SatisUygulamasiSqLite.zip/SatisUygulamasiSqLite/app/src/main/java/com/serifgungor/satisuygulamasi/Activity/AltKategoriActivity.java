package com.serifgungor.satisuygulamasi.Activity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.serifgungor.satisuygulamasi.Adapter.AdapterAltKategori;
import com.serifgungor.satisuygulamasi.Helper.DatabaseHelper;
import com.serifgungor.satisuygulamasi.Model.AltKategori;
import com.serifgungor.satisuygulamasi.Model.Kategori;
import com.serifgungor.satisuygulamasi.R;

import java.util.ArrayList;

public class AltKategoriActivity extends AppCompatActivity {

    ListView altKategori;
    ArrayList<AltKategori> altKategoriler = new ArrayList<>();
    AdapterAltKategori adapterAltKategori;
    DatabaseHelper dbHelper;
    SQLiteDatabase db;
    Cursor c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alt_kategori);


        /*
        Bir önceki sayfadan doğrudan bir nesneyi, ikinci sayfamıza taşımak istiyorsak
        gönderdiğimiz object'in serializable türünde olması gerekmektedir.
         */
        Kategori kategori = (Kategori)getIntent().getSerializableExtra("kategori");
        this.setTitle(kategori.getAd());

        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        altKategori = findViewById(R.id.listViewAltKategoriler);
        altKategoriler = new ArrayList<>();

        /*
        kat.add(new Kategori(1,"Bilgisayar",""));
        kat.add(new Kategori(2,"Giyim",""));
        kat.add(new Kategori(3,"Beyaz Eşya",""));
        kat.add(new Kategori(4,"Mobilya",""));
         */

        try{
            dbHelper = new DatabaseHelper(getApplicationContext());
            dbHelper.createDatabase();
            db = dbHelper.getReadableDatabase();
            c = db.rawQuery("Select * from AltKategori where ustKategoriId="+kategori.getId(),null);

            while (c.moveToNext()) {
                altKategoriler.add(new AltKategori(
                        c.getInt(c.getColumnIndex("id")),
                        c.getInt(c.getColumnIndex("ustKategoriId")),
                        c.getString(c.getColumnIndex("kategoriAdi")),
                        c.getString(c.getColumnIndex("kategoriResim")),
                        c.getString(c.getColumnIndex("kategoriAciklama"))));
            }
        }catch(Exception e){
            Log.e("DB_LOG",e.getMessage());
            Log.e("DB_LOG","Veritabanı oluşturulamadı veya kopyalanamadı !");
        }
            //int id, int ustKategoriId, String kategoriAdi, String kategoriResim, String kategoriAciklama
        //   altKategoriler.add(new AltKategori(1,1,"Masaüstü Bilgisayar","https://yorumbudur.com/content/icerik/big/casper-nirvana-d2h-g440-4l05e-masaustu-bilgisayar_yorumbudurcom.jpg","Masaüstü bilgisayar parçaları burada"));


        adapterAltKategori = new AdapterAltKategori(altKategoriler,getApplicationContext());
        altKategori.setAdapter(adapterAltKategori);

        altKategori.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(),UrunlerActivity.class);
                intent.putExtra("altKategori",altKategoriler.get(i));
                startActivity(intent);
            }
        });


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId()==android.R.id.home){

            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
