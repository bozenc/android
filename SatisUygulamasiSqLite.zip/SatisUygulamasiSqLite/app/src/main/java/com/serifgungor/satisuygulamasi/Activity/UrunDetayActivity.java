package com.serifgungor.satisuygulamasi.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.serifgungor.satisuygulamasi.Model.Urun;
import com.serifgungor.satisuygulamasi.R;

public class UrunDetayActivity extends AppCompatActivity {

    TextView tvBaslik,tvFiyat,tvAciklama;
    ImageView ivUrunDetay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_urun_detay);
        Urun urun = (Urun)getIntent().getSerializableExtra("urun");
        this.setTitle(urun.getBaslik());

        ivUrunDetay = findViewById(R.id.ivUrunDetayResim);
        tvBaslik = findViewById(R.id.tvUrunDetayBaslik);
        tvAciklama = findViewById(R.id.tvUrunDetayAciklama);
        tvFiyat = findViewById(R.id.tvUrunDetayFiyat);


        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId()==android.R.id.home)
        {
            finish();

        }
        return super.onOptionsItemSelected(item);
    }
}
