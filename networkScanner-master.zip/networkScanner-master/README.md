networkScanner
==============

  License: Apache 2.0 http://www.apache.org/licenses/LICENSE-2.0

  Description:
A network scanner for android. Uses the new UI components Cardview and Recyclview. Displays the IP, Host Name, and MAC address for all of the network devices on the network

Feel free to fork, improve, and use. In the spirit of open source, submit pull requests! I will do my best to communicate and merge them.


[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/dmashuda/networkscanner/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

