package com.serifgungor.satisuygulamasi.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.GridView;

import com.serifgungor.satisuygulamasi.Adapter.AdapterUrun;
import com.serifgungor.satisuygulamasi.Model.AltKategori;
import com.serifgungor.satisuygulamasi.Model.Urun;
import com.serifgungor.satisuygulamasi.R;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class UrunlerActivity extends AppCompatActivity {
    GridView gridView;
    ArrayList<Urun> urunler = new ArrayList<>();
    AdapterUrun adapterUrun;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_urunler);

        AltKategori altKategori = (AltKategori)getIntent().getSerializableExtra("altKategori");

        this.setTitle(altKategori.getKategoriAdi() +"Ürünleri");
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        gridView = findViewById(R.id.gridViewUrunler);
        if (altKategori.getId()==1){

            urunler.add(new Urun(1,1,"Asus Masaüstü pc",2495,"https://productimages.hepsiburada.net/s/6/280-413/9747790331954.jpg","asus açıklamaaaaa"));
            urunler.add(new Urun(1,1,"Hp Masaüstü pc",2695,"https://cdn.vatanbilgisayar.com/UPLOAD/PRODUCT/HP/thumb/v2-91495_small.jpg","hp açıklamaaaaa"));
        }
        else if (altKategori.getId()==2){

            urunler.add(new Urun(2,2,"Asus Masaüstü pc",2495,"https://productimages.hepsiburada.net/s/6/280-413/9747790331954.jpg","asus açıklamaaaaa"));
            urunler.add(new Urun(2,2,"Hp Masaüstü pc",2695,"https://cdn.vatanbilgisayar.com/UPLOAD/PRODUCT/HP/thumb/v2-91495_small.jpg","hp açıklamaaaaa"));


        }

        adapterUrun = new AdapterUrun(urunler,getApplicationContext());
        gridView.setAdapter(adapterUrun);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(),UrunDetayActivity.class);
                intent.putExtra("urun",urunler.get(position));
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId()==android.R.id.home)
        {
            finish();

        }
        return super.onOptionsItemSelected(item);
    }
}
