package com.serifgungor.satisuygulamasi.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.serifgungor.satisuygulamasi.Adapter.AdapterAltKategori;
import com.serifgungor.satisuygulamasi.Model.AltKategori;
import com.serifgungor.satisuygulamasi.Model.Kategori;
import com.serifgungor.satisuygulamasi.R;

import java.util.ArrayList;

public class AltKategoriActivity extends AppCompatActivity {

    ListView altKategori;
    ArrayList<AltKategori> altKategoriler;
    AdapterAltKategori adapterAltKategori;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alt_kategori);


        /*
        Bir önceki sayfadan doğrudan bir nesneyi, ikinci sayfamıza taşımak istiyorsak
        gönderdiğimiz object'in serializable türünde olması gerekmektedir.
         */
        Kategori kategori = (Kategori)getIntent().getSerializableExtra("kategori");
        this.setTitle(kategori.getAd());

        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        altKategori = findViewById(R.id.listViewAltKategoriler);
        altKategoriler = new ArrayList<>();

        /*
        kat.add(new Kategori(1,"Bilgisayar",""));
        kat.add(new Kategori(2,"Giyim",""));
        kat.add(new Kategori(3,"Beyaz Eşya",""));
        kat.add(new Kategori(4,"Mobilya",""));
         */

        if(kategori.getId()==1){
            //int id, int ustKategoriId, String kategoriAdi, String kategoriResim, String kategoriAciklama
            altKategoriler.add(new AltKategori(1,1,"Masaüstü Bilgisayar","https://yorumbudur.com/content/icerik/big/casper-nirvana-d2h-g440-4l05e-masaustu-bilgisayar_yorumbudurcom.jpg","Masaüstü bilgisayar parçaları burada"));
            altKategoriler.add(new AltKategori(2,1,"Dizüstü Bilgisayar","https://cdn.vatanbilgisayar.com/UPLOAD/PRODUCT/ASUS/thumb/v2-68571-1_medium.jpg","Dizüstü bilgisayar parçaları burada"));
            altKategoriler.add(new AltKategori(3,1,"Sabit HDD/SDD","http://img03.blogcu.com/images/i/l/g/ilginchersey/51bba19159c999d5115df81a42a7821b_1280112507.jpg","Masaüstü bilgisayar parçaları burada"));

        }else if(kategori.getId()==2){

            altKategoriler.add(new AltKategori(4,2,"T-Shirt","https://productimages.hepsiburada.net/s/5/280-413/9700284235826.jpg","Bütçenize uygun T-Shirtler burada"));
            altKategoriler.add(new AltKategori(5,2,"Kazak","https://cdn-gap.akinon.net/products/2018/05/10/37233/6feffb52-5830-4e35-b33c-ca209f45f950_size520x693_cropCenter.jpg","Bütçenize uygun Kazaklar burada"));
            altKategoriler.add(new AltKategori(6,2,"Pantolon","https://img-morhipo.mncdn.com/mnresize/1200/1645/productimages/i/8681579992044/[img][5][5].jpg","Bütçenize uygun Pantolonlar burada"));

        }
        else if(kategori.getId()==3){

            altKategoriler.add(new AltKategori(7,3,"Buzdolabı","https://productimages.hepsiburada.net/s/2/431/9549418430514.jpg","En yeni teknoloji buzdolapları"));
            altKategoriler.add(new AltKategori(8,3,"Fırın","https://cdn.akakce.com/akel/akel-af380-termostatli-saatli-midi-z.jpg","En iyi pişiren fırınlar"));
            altKategoriler.add(new AltKategori(9,3,"Ankastre","https://cdn.cimri.io/image/240x240/kumtelblackpointasfdtkotahdfkoankastreset_89823361.jpg","en güzel ankastreler"));

        }
        else if(kategori.getId()==4){

            altKategoriler.add(new AltKategori(10,4,"Köşe Takımı","https://www.engince.com.tr/montana-kose-takimi-34755-46-B.jpg","evinizin köşesine uygun köşe takmıları"));
            altKategoriler.add(new AltKategori(11,4,"TV Ünitesi","https://s.eticaretbox.com/2408/pictures/YIWMMXNOMQ8282017132015_natalee-tv-unitesi.jpg","en modern tv üniteleri"));
            altKategoriler.add(new AltKategori(12,4,"Orta Sehba","https://www.evmoda.com.tr/asos-orta-sehpa-orta-sehpalar-evmoda-1050-10-B.jpg","en çağdaş orta sehbalar"));

        }

        adapterAltKategori = new AdapterAltKategori(altKategoriler,getApplicationContext());
        altKategori.setAdapter(adapterAltKategori);

        altKategori.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(),UrunlerActivity.class);
                intent.putExtra("altKategori",altKategoriler.get(i));
                startActivity(intent);
            }
        });


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId()==android.R.id.home){

            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
