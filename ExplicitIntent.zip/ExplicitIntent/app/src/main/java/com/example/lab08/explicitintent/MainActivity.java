package com.example.lab08.explicitintent;

import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        try{
            Intent intent = new Intent();
            String paketAdi = "com.facebook.katana";
            String sinifAdi = paketAdi+".LoginActivity";
            intent.setComponent(new ComponentName(paketAdi,sinifAdi));
            startActivity(intent);
        }catch (ActivityNotFoundException e){
            Toast.makeText(getApplicationContext(),"Telefonunuzda Facebook Uygulaması yüklü değildir.",Toast.LENGTH_LONG).show();
        }
    }
}
