package com.example.lab08.ornek2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class secondActivity extends AppCompatActivity {
    EditText etAdSoyad,etUniversite,etSinif;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        etAdSoyad = findViewById(R.id.etAdSoyad2);
        etUniversite = findViewById(R.id.etUniversite2);
        etSinif = findViewById(R.id.etSinif2);

        Bundle bundle = getIntent().getExtras();
        String adSoyad = bundle.getString("adSoyad");
        String Universite = bundle.getString("Universite");
        int Sinif = bundle.getInt("Sinif");

        etAdSoyad.setText(adSoyad);
        etUniversite.setText(Universite);
        etSinif.setText(""+Sinif);
    }
}
