package com.example.lab08.splashactivity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ucuncuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ucuncu);
    }
}
