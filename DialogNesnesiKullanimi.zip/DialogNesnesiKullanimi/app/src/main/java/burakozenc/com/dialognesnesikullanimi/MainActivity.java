package burakozenc.com.dialognesnesikullanimi;

import android.app.Dialog;
import android.content.DialogInterface;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button btnAlert;
    Button btnCustomAlertDialog;
    Button btnRadioGrup;


    public void  radioGrupDialogUret(String[] elemanlar , String baslik){
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.custom_dialog_radiogrup);
        TextView tvBaslik = dialog.findViewById(R.id.tvRadyoBaslik);
        RadioGroup radioGroup = dialog.findViewById(R.id.radioGrup);

        for (int i =0; i<elemanlar.length; i++){
            RadioButton btn = new RadioButton(getApplicationContext());
            btn.setText(elemanlar[i]);
            radioGroup.addView(btn);

        }
        tvBaslik.setText(baslik);

        Button btnKapat = dialog.findViewById(R.id.btnRadioKapat);
        btnKapat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();

    }

    public void customAlertDialog(@NonNull String baslik,
                                  @NonNull String aciklama,
                                  @Nullable String olumluButonBaslik,
                                  @Nullable String olumsuzButonBaslik,
                                  @Nullable String kararsizBaslik,
                                  boolean vazgecilebilme ) {
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.custom_alert_dialog);

        TextView tvBaslik = dialog.findViewById(R.id.tvBaslik);
        TextView tvAciklama = dialog.findViewById(R.id.tvAciklama);

        Button btnOlumlu,btnOlumsuz,btnKararsiz;

        btnOlumlu = dialog.findViewById(R.id.btnEvet);
        btnOlumsuz = dialog.findViewById(R.id.btnHayir);
        btnKararsiz = dialog.findViewById(R.id.btnVazgec);
        dialog.setCancelable(vazgecilebilme);
        tvBaslik.setText(baslik);
        tvAciklama.setText(aciklama);

        if (olumluButonBaslik.isEmpty())
        {

        }     else{

            btnOlumlu.setText(olumluButonBaslik);
            btnOlumlu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //olumlu tıklama olayı
                    dialog.dismiss();
                }
            });
        }
        if (olumsuzButonBaslik.isEmpty()){

            btnOlumsuz.setVisibility(View.GONE);

        }
        else {

            btnOlumsuz.setText(olumsuzButonBaslik);
            btnOlumsuz.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //olumsuz tıklama
                }
            });
        }

        if (kararsizBaslik.isEmpty()){

            btnKararsiz.setVisibility(View.GONE);
        }
        else {

            btnKararsiz.setText(kararsizBaslik);
            btnKararsiz.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
        }
        dialog.show();

    }
    public void alertDialogUret(){
        AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
        adb.setTitle("Dialog Baslk");
        adb.setMessage("mesaj içerik");

        adb.setNegativeButton("hyr", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        adb.setPositiveButton("evet", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        adb.setNeutralButton("vazgeç",null);

        adb.show();






        }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnRadioGrup = findViewById(R.id.btnCustomRadioGrup);


        btnAlert = findViewById(R.id.btnAlert);
        btnCustomAlertDialog = findViewById(R.id.btnCustomAlertDialog);

        btnCustomAlertDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customAlertDialog("Uygulama Kapatılsın mı ?","Açıklama","Kabul","Hayır","Bilemiyorum",false);


            }
        });


        btnAlert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                alertDialogUret();

            }
        });

        btnRadioGrup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                radioGrupDialogUret(new String[]{"Mavi","Kırmızı","Sarı","Laci"},"En Sevdiğin Renk ?");
            }
        });



    }
}
