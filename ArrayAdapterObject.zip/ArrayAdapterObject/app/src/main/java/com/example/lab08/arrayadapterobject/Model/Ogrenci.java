package com.example.lab08.arrayadapterobject.Model;

public class Ogrenci {
    private String ogrenciAdi;
    private String ogrenciSoyadi;
    private String ogrenciBolum;
    private String ogrenciEmail;

    @Override
    public String toString() {
        return "Ogrenci{" +
                "ogrenciAdi='" + ogrenciAdi + '\'' +
                ", ogrenciSoyadi='" + ogrenciSoyadi + '\'' +
                ", ogrenciBolum='" + ogrenciBolum + '\'' +
                ", ogrenciEmail='" + ogrenciEmail + '\'' +
                '}';
    }

    public Ogrenci(String s, String s1, String s2){


    }

    public Ogrenci(String ogrenciAdi, String ogrenciSoyadi, String ogrenciBolum, String ogrenciEmail) {
        this.ogrenciAdi = ogrenciAdi;
        this.ogrenciSoyadi = ogrenciSoyadi;
        this.ogrenciBolum = ogrenciBolum;
        this.ogrenciEmail = ogrenciEmail;
    }


    public String getOgrenciAdi() {
        return ogrenciAdi;
    }

    public void setOgrenciAdi(String ogrenciAdi) {
        this.ogrenciAdi = ogrenciAdi;
    }

    public String getOgrenciSoyadi() {
        return ogrenciSoyadi;
    }

    public void setOgrenciSoyadi(String ogrenciSoyadi) {
        this.ogrenciSoyadi = ogrenciSoyadi;
    }

    public String getOgrenciBolum() {
        return ogrenciBolum;
    }

    public void setOgrenciBolum(String ogrenciBolum) {
        this.ogrenciBolum = ogrenciBolum;
    }

    public String getOgrenciEmail() {
        return ogrenciEmail;
    }

    public void setOgrenciEmail(String ogrenciEmail) {
        this.ogrenciEmail = ogrenciEmail;
    }
}
