package com.example.lab08.arrayadapterobject.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.lab08.arrayadapterobject.Model.Ogrenci;
import com.example.lab08.arrayadapterobject.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ArrayList<Ogrenci> ogrenciler = new ArrayList<>();
    ListView listView;
    ArrayAdapter<Ogrenci> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.listView);
        //    public Ogrenci(String ogrenciAdi, String ogrenciSoyadi, String ogrenciBolum, String ogrenciEmail)
        ogrenciler.add(new Ogrenci("Burak1","Özenç","Bilgisayar","burakozenc@gmail.com"));
        ogrenciler.add(new Ogrenci("Burak2","Özenç","Bilgisayar","burakozenc@gmail.com"));
        ogrenciler.add(new Ogrenci("Burak3","Özenç","Bilgisayar","burakozenc@gmail.com"));
        ogrenciler.add(new Ogrenci("Burak3","Özenç","Bilgisayar","burakozenc@gmail.com"));

        adapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1,ogrenciler);
        listView.setAdapter(adapter);
    }
}
