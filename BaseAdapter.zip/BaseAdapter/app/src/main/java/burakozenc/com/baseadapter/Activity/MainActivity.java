package burakozenc.com.baseadapter.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

import burakozenc.com.baseadapter.Adapter.AdapterMeyve;
import burakozenc.com.baseadapter.Model.Meyve;
import burakozenc.com.baseadapter.R;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<Meyve> meyveler = new ArrayList<>();
    AdapterMeyve adapterMeyve;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);

        meyveler.add(new Meyve("Elma",R.drawable.elma));
        meyveler.add(new Meyve("Armut",R.drawable.armut));
        meyveler.add(new Meyve("Erik",R.drawable.erik));
        meyveler.add(new Meyve("Hindistan Cevizi",R.drawable.hindistancevizi));
        meyveler.add(new Meyve("Kavun",R.drawable.kavun));

        adapterMeyve = new AdapterMeyve(meyveler,getApplicationContext());
        listView.setAdapter(adapterMeyve);




    }
}
