package burakozenc.com.baseadapter.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import burakozenc.com.baseadapter.Model.Meyve;
import burakozenc.com.baseadapter.R;

public class AdapterMeyve extends BaseAdapter{

    private ArrayList <Meyve> meyveler;
    private Context context;
    private LayoutInflater layoutInflater;

    public AdapterMeyve(){}
    public AdapterMeyve (ArrayList <Meyve> meyveler,Context context){
        this.context = context;
        this.meyveler = meyveler;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);


    }


    @Override
    public int getCount() {
        //Listenin eleman sayısı
        return meyveler.size();
    }

    @Override
    public Object getItem(int position) {
        //Listenin eleman sayısı
        return position;
    }

    @Override
    public long getItemId(int position) {
        //Listedeki elemanın kaçıncı sırada olduğu
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //Liste elemanının satır görüntüsünü döner

        View v = layoutInflater.inflate(R.layout.meyve_satir_goruntusu,null);
        ImageView ivResim = v.findViewById(R.id.ivResim);
        TextView tvBaslik = v.findViewById(R.id.tvBaslik);
        tvBaslik.setText(meyveler.get(position).getAd());
        ivResim.setImageResource(meyveler.get(position).getResim());


        return v;


    }
}
