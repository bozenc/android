package com.example.lab08.ornek1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class secondActivity extends AppCompatActivity {
    TextView tvinf;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        tvinf = findViewById(R.id.tvinfo);
        String param = getIntent().getStringExtra("param");

        tvinf.setText(param);
    }
}
