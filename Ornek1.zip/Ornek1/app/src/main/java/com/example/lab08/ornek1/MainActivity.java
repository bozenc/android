package com.example.lab08.ornek1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    ImageView Aslan;
    ImageView Sirtlan;
    ImageView Kedi;
    ImageView Koala;
    Button btn;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn = findViewById(R.id.btnSend);
        Aslan = findViewById(R.id.ivAslan);
        Sirtlan = findViewById(R.id.ivSirtlan);
        Kedi = findViewById(R.id.ivKedi);
        Koala = findViewById(R.id.ivKoala);

        Aslan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,secondActivity.class);
                intent.putExtra("param","aslan");
                startActivity(intent);
            }


        });

        Sirtlan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,secondActivity.class);
                intent.putExtra("param","sirtlan");
                startActivity(intent);
            }


        });
        Kedi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,secondActivity.class);
                intent.putExtra("param","kedi");
                startActivity(intent);
            }


        });
        Koala.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,secondActivity.class);
                intent.putExtra("param","koala");
                startActivity(intent);
            }


        });

    }
}
