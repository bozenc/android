package burakozenc.com.baseadapterornek1.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import burakozenc.com.baseadapterornek1.Model.Oyuncu;
import burakozenc.com.baseadapterornek1.R;

public class AdapterOyuncular extends BaseAdapter {
    private ArrayList<Oyuncu> oyuncular;
    private Context context;
    private LayoutInflater layoutInflater;

    public AdapterOyuncular() {
    }


    public AdapterOyuncular(ArrayList<Oyuncu> oyuncular, Context context, LayoutInflater layoutInflater) {
        this.oyuncular = oyuncular;
        this.context = context;
        this.layoutInflater = layoutInflater;
    }


    @Override
    public int getCount() {
        return oyuncular.size();
    }

    @Override
    public Object getItem(int position) {
        return oyuncular.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = layoutInflater.inflate(R.layout.oyuncu_satir_goruntusu, null);

        TextView tvAdsoyad, tvYas, tvFormaNo;
        ImageView ivResim = v.findViewById(R.id.ivOyuncu);
        tvAdsoyad = v.findViewById(R.id.tvAdSoyad);
        tvFormaNo = v.findViewById(R.id.tvFormaNo);
        tvYas = v.findViewById(R.id.tvYas);

        tvAdsoyad.setText(oyuncular.get(position).getAdSoyad());
        tvFormaNo.setText("" + oyuncular.get(position).getFormaNo());
        tvYas.setText("" + oyuncular.get(position).getYas());

        int resim = v.getResources().getIdentifier(
                oyuncular.get(position).getResim(),
                "drawable",
                context.getPackageName());
        ivResim.setImageResource(resim);
        return v;
    }

}