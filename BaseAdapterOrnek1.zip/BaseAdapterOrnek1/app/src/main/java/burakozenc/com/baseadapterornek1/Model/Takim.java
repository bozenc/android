package burakozenc.com.baseadapterornek1.Model;

public class Takim {
    private String takim;
    private int resim;

    public Takim() {
    }

    public Takim(String takim, int resim) {
        this.takim = takim;
        this.resim = resim;
    }

    public String getTakim() {
        return takim;
    }

    public void setTakim(String takim) {
        this.takim = takim;
    }

    public int getResim() {
        return resim;
    }

    public void setResim(int resim) {
        this.resim = resim;
    }
}

