package burakozenc.com.baseadapterornek1.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import burakozenc.com.baseadapterornek1.Adapter.AdapterTakim;
import burakozenc.com.baseadapterornek1.Model.Takim;
import burakozenc.com.baseadapterornek1.R;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    ArrayList<Takim> takimlar = new ArrayList<>();
    AdapterTakim adapterTakim;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);

        takimlar.add(new Takim("Galatasaray",R.drawable.gs));
        takimlar.add(new Takim("Fenerbahçe",R.drawable.fb));
        takimlar.add(new Takim("Trabzon",R.drawable.ts));
        takimlar.add(new Takim("Osmanlıspor",R.drawable.os));

        adapterTakim = new AdapterTakim(takimlar,getApplicationContext());
        listView.setAdapter(adapterTakim);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


                /*
                Toast.makeText(
                        getApplicationContext(),"Tıklanan: "+takimlar.get(position).getTakim(),
                        Toast.LENGTH_LONG).show();

                */
                startActivity(new Intent(getApplicationContext(),Oyuncular.class).putExtra("takim_adi",takimlar.get(position).getTakim()));


            }
        });
    }
}
