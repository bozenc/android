package burakozenc.com.baseadapterornek1.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import burakozenc.com.baseadapterornek1.Model.Takim;
import burakozenc.com.baseadapterornek1.R;

public class AdapterTakim extends BaseAdapter {
    private ArrayList<Takim> takimlar;
    private Context context;
    private LayoutInflater layoutInflater;

    public AdapterTakim(){}
    public AdapterTakim (ArrayList <Takim> takimlar,Context context){
        this.context = context;
        this.takimlar = takimlar;
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);


    }


    @Override
    public int getCount() {
        //Listenin eleman sayısı
        return takimlar.size();
    }

    @Override
    public Object getItem(int position) {
        //Listenin eleman sayısı
        return position;
    }

    @Override
    public long getItemId(int position) {
        //Listedeki elemanın kaçıncı sırada olduğu
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //Liste elemanının satır görüntüsünü döner

        View v = layoutInflater.inflate(R.layout.takim_satir,null);
        ImageView ivResim = v.findViewById(R.id.ivTakim);
        TextView tvBaslik = v.findViewById(R.id.tvTakim);
        tvBaslik.setText(takimlar.get(position).getTakim());
        ivResim.setImageResource(takimlar.get(position).getResim());


        return v;


    }
}