package burakozenc.com.baseadapterornek1.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import burakozenc.com.baseadapterornek1.Adapter.AdapterOyuncular;
import burakozenc.com.baseadapterornek1.Model.Oyuncu;
import burakozenc.com.baseadapterornek1.R;

public class Oyuncular extends AppCompatActivity {
    ListView listView;
    AdapterOyuncular adapterOyuncular;
    ArrayList<Oyuncu> oyuncular = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oyuncular);

        String takim = getIntent().getStringExtra("takim_adi");
        setTitle(takim);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listView = findViewById(R.id.listViewOyuncular);

        //int id, String adSoyad, String resim, int yas, int formaNo
        if ("Galatasaray".equals(takim)) {
            oyuncular.add(new Oyuncu(1,"elcinsangu", "elcin_sangu", 12, 2));
            oyuncular.add(new Oyuncu(2,"hasankoksal", "hasan_koksal", 12, 2));
            oyuncular.add(new Oyuncu(3,"muratboz", "murat_boz", 12, 2));
            oyuncular.add(new Oyuncu(4,"oznurserceler", "oznur_serceleru", 12, 2));

        } else if ("Fenerbahçe".equals(takim))
        {
            oyuncular.add(new Oyuncu(1,"elcinsangu", "elcin_sangu", 12, 2));
            oyuncular.add(new Oyuncu(2,"hasankoksal", "hasan_koksal", 12, 2));
            oyuncular.add(new Oyuncu(3,"muratboz", "murat_boz", 12, 2));
            oyuncular.add(new Oyuncu(4,"oznurserceler", "oznur_serceleru", 12, 2));

        }


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId()==android.R.id.home){
            finish();

        }

        return super.onOptionsItemSelected(item);
    }
}
