package burakozenc.com.mp3playerapp.Model;

import java.io.Serializable;

public class MuzikKategori implements Serializable {

    private int kategoriId;
    private String kategoriAdi;
    private String kategoriResim;

    public MuzikKategori() {
    }

    public MuzikKategori(int kategoriId, String kategoriAdi, String kategoriResim) {
        this.kategoriId = kategoriId;
        this.kategoriAdi = kategoriAdi;
        this.kategoriResim = kategoriResim;
    }

    public int getKategoriId() {
        return kategoriId;
    }

    public void setKategoriId(int kategoriId) {
        this.kategoriId = kategoriId;
    }

    public String getKategoriAdi() {
        return kategoriAdi;
    }

    public void setKategoriAdi(String kategoriAdi) {
        this.kategoriAdi = kategoriAdi;
    }

    public String getKategoriResim() {
        return kategoriResim;
    }

    public void setKategoriResim(String kategoriResim) {
        this.kategoriResim = kategoriResim;
    }
}
