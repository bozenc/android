package burakozenc.com.mp3playerapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import burakozenc.com.mp3playerapp.Model.MuzikKategori;
import burakozenc.com.mp3playerapp.R;

public class AdapterMuzikKategori extends BaseAdapter {

    private Context context;
    private ArrayList<MuzikKategori> muzikKategorileri;
    private LayoutInflater layoutInflater;


    @Override
    public int getCount() {
        return muzikKategorileri.size();
    }

    @Override
    public Object getItem(int position) {
        return muzikKategorileri.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = layoutInflater.inflate(R.layout.kategori_satir_goruntusu,null);

        ImageView ivKategoriResim;
        TextView tvKategoriBaslik;

        ivKategoriResim = v.findViewById(R.id.ivKategoriResim);
        tvKategoriBaslik = v.findViewById(R.id.tvKategoriBaslik);

        Glide
                .with(context)
                .load(muzikKategorileri.get(position).getKategoriResim())
                .into(ivKategoriResim);

        tvKategoriBaslik.setText(muzikKategorileri.get(position).getKategoriAdi());

        return v;
    }


}
