package burakozenc.com.mp3playerapp.Helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "mp3database.db";



    //Tabloların her biri, static stringler ile üretildi.
    private static final String TABLO_SANATCI = "Sanatci";
    private static final String TABLO_ESER = "Eser";
    private static final String TABLO_ALBUM = "Album";
    private static final String TABLO_MUZIK_KATEGORI = "MuzikKategori";

    //Sanatci Tablosu kolon isimleri
    private static final String TBL_SANATCI_ID = "sanatciId";
    private static final String TBL_SANATCI_KATEGORIID = "kategoriId";
    private static final String TBL_SANATCI_ADSOYAD = "sanatciAdSoyad";
    private static final String TBL_SANATCI_DOGUMYILI = "sanatciDogumYili";
    private static final String TBL_SANATCI_DIL = "sanatciDil";
    private static final String TBL_SANATCI_ULKE = "sanatciUlke";
    private static final String TBL_SANATCI_ACIKLAMA = "sanatciAciklama";
    private static final String TBL_SANATCI_RESIM = "sanatciResim";

    //Eser Tablosu kolon isimleri
    private static final String TBL_ESER_ID = "eserId";
    private static final String TBL_ESER_ALBUMID = "albumId";
    private static final String TBL_ESER_SANATCIID = "sanatciId";
    private static final String TBL_ESER_ADI = "eserAdi";
    private static final String TBL_ESER_ACIKLAMA = "eserAciklama";
    private static final String TBL_ESER_YAYINYILI = "yayinYili";
    private static final String TBL_ESER_GORSEL = "eserGorseli";
    private static final String TBL_ESER_MP3DOSYAADRESI = "mp3DosyaAdresi";

    //Album Tablosu kolon isimleri
    private static final String TBL_ALBUM_ID = "albumId";
    private static final String TBL_ALBUM_ADI = "albumAdi";
    private static final String TBL_ALBUM_ACIKLAMA = "albumAciklama";
    private static final String TBL_ALBUM_SANATCIID = "sanatciId";
    private static final String TBL_ALBUM_CIKISTARIHI = "cikisTarihi";

    //MuzikKategori Tablosu kolon isimleri
    private static final String TBL_MUZIKKATEGORI_ID = "kategoriId";
    private static final String TBL_MUZIKKATEGORI_ADI = "kategoriAdi";
    private static final String TBL_MUZIKKATEGORI_RESIM = "kategoriResim";


    private HashMap hp;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME , null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {



/*


        CREATE TABLE IF NOT EXİSTS `Eser` (
	`eserId`	INTEGER PRIMARY KEY AUTOINCREMENT,
	`albumId`	INTEGER,
	`sanatciId`	INTEGER,
	`eserAdi`	VARCHAR,
	`eserAciklama`	TEXT,
	`yayinYili`	INTEGER,
	`eserGorseli`	TEXT,
	`mp3DosyaAdresi`	TEXT
);

        CREATE TABLE IF NOT EXİSTS `Album` (
	`albumId`	INTEGER PRIMARY KEY AUTOINCREMENT,
	`albumAdi`	VARCHAR,
	`albumAciklama`	TEXT,
	`sanatciId`	INTEGER,
	`cikisTarihi`	VARCHAR(25)

	CREATE TABLE IF NOT EXİSTS `MuzikKategori` (
	`kategoriId`	INTEGER PRIMARY KEY AUTOINCREMENT,
	`kategoriAdi`	VARCHAR,
	`kategoriResim`	TEXT
);


);*/

        db.execSQL("CREATE TABLE IF NOT EXISTS "+TABLO_SANATCI+" ("+TBL_SANATCI_ID+" INTEGER PRIMARY KEY AUTOINCREMENT,"+TBL_SANATCI_KATEGORIID+" INTEGER,"+TBL_SANATCI_ADSOYAD+" VARCHAR,"+TBL_SANATCI_DOGUMYILI+" INTEGER,"+TBL_SANATCI_DIL+" VARCHAR(25),"+TBL_SANATCI_ULKE+" VARCHAR(75),"+TBL_SANATCI_ACIKLAMA+" TEXT,"+TBL_SANATCI_RESIM+" TEXT)");

        StringBuilder muzikKategori = new StringBuilder();
        muzikKategori.append("CREATE TABLE IF NOT EXISTS "+TABLO_MUZIK_KATEGORI+" (");
        muzikKategori.append(""+TBL_MUZIKKATEGORI_ID+" INTEGER PRIMARY KEY AUTOINCREMENT,");
        muzikKategori.append(""+TBL_MUZIKKATEGORI_ADI+" VARCHAR,");
        muzikKategori.append(""+TBL_MUZIKKATEGORI_RESIM+" TEXT)");
        db.execSQL(muzikKategori.toString());


        db.execSQL("CREATE TABLE IF NOT EXISTS Album (albumId INTEGER PRIMARY KEY AUTOINCREMENT,albumAdi VARCHAR,albumAciklama TEXT,sanatciId INTEGER,cikisTarihi VARCHAR(25))");


        db.execSQL("CREATE TABLE IF NOT EXISTS Eser (eserId INTEGER PRIMARY KEY AUTOINCREMENT,albumId INTEGER,sanatciId INTEGER,eserAdi VARCHAR,eserAciklama TEXT,yayinYili INTEGER,eserGorseli TEXT,mp3DosyaAdresi TEXT)");

        // TODO Auto-generated method stub
        db.execSQL("");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS contacts");
        onCreate(db);
    }

    public boolean insertContact (String name, String phone, String email, String street,String place) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("phone", phone);
        contentValues.put("email", email);
        contentValues.put("street", street);
        contentValues.put("place", place);
        db.insert("contacts", null, contentValues);
        return true;
    }

    public Cursor getData(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from contacts where id="+id+"", null );
        return res;
    }

    public int numberOfRows(){
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, CONTACTS_TABLE_NAME);
        return numRows;
    }

    public boolean updateContact (Integer id, String name, String phone, String email, String street,String place) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("phone", phone);
        contentValues.put("email", email);
        contentValues.put("street", street);
        contentValues.put("place", place);
        db.update("contacts", contentValues, "id = ? ", new String[] { Integer.toString(id) } );
        return true;
    }

    public Integer deleteContact (Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("contacts",
                "id = ? ",
                new String[] { Integer.toString(id) });
    }

    public ArrayList<String> getAllCotacts() {
        ArrayList<String> array_list = new ArrayList<String>();

        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from contacts", null );
        res.moveToFirst();

        while(res.isAfterLast() == false){
            array_list.add(res.getString(res.getColumnIndex(CONTACTS_COLUMN_NAME)));
            res.moveToNext();
        }
        return array_list;
    }
}
