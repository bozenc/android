package burakozenc.com.mp3playerapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import burakozenc.com.mp3playerapp.Model.MuzikKategori;
import burakozenc.com.mp3playerapp.Model.Sanatci;
import burakozenc.com.mp3playerapp.R;

public class AdapterSanatci extends BaseAdapter{

    private Context context;
    private ArrayList<Sanatci> sanatcilar;
    private LayoutInflater layoutInflater;

    @Override
    public int getCount() {
        return sanatcilar.size();
    }

    @Override
    public Object getItem(int position) {
        return sanatcilar.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = layoutInflater.inflate(R.layout.sanatci_satir_goruntusu,null);

        ImageView ivSanatciResim;
        TextView tvSanatciAdSoyad,tvSanatciDogumYili;

        ivSanatciResim = v.findViewById(R.id.ivSanatciResim);
        tvSanatciAdSoyad = v.findViewById(R.id.tvSanatciAdSoyad);
        tvSanatciDogumYili = v.findViewById(R.id.tvSanatciDogumYili);

        Glide
                .with(context)
                .load(sanatcilar.get(position).getSanatciResim())
                .into(ivSanatciResim);

        tvSanatciAdSoyad.setText(sanatcilar.get(position).getSanatciAdSoyad());
        tvSanatciDogumYili.setText(Integer.toString(sanatcilar.get(position).getSanatciDogumYili()));

        return v;
    }
}
