package burakozenc.com.mp3playerapp.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

import burakozenc.com.mp3playerapp.Adapter.AdapterMuzikKategori;
import burakozenc.com.mp3playerapp.Model.MuzikKategori;
import burakozenc.com.mp3playerapp.R;

public class KategorilerActivity extends AppCompatActivity {
    ListView listView;
    AdapterMuzikKategori adapterMuzikKategori;
    ArrayList<MuzikKategori> muzikKategori = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kategoriler);
    }
}
