package burakozenc.com.mp3playerapp.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

import burakozenc.com.mp3playerapp.Model.Eser;
import burakozenc.com.mp3playerapp.R;

public class AdapterEser extends BaseAdapter {

    private Context context;
    private ArrayList<Eser> eserler;
    private LayoutInflater layoutInflater;

    @Override
    public int getCount() {
        return eserler.size();
    }

    @Override
    public Object getItem(int position) {
        return eserler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = layoutInflater.inflate(R.layout.eser_satir_goruntusu,null);
        ImageView ivEserResim;
        TextView tvEserBaslik,tvEserYayinYili,tvEserAciklama;

        ivEserResim = v.findViewById(R.id.ivEserResim);
        tvEserBaslik = v.findViewById(R.id.tvEserBaslik);
        tvEserAciklama = v.findViewById(R.id.tvEserAciklama);
        tvEserYayinYili = v.findViewById(R.id.tvEserYayinYili);

        Glide
                .with(context)
                .load(eserler.get(position).getEserGorseli())
                .into(ivEserResim);
        tvEserBaslik.setText(eserler.get(position).getEserAdi());
        tvEserAciklama.setText(eserler.get(position).getEserAciklama());
        tvEserYayinYili.setText(""+eserler.get(position).getYayinYili());

        return v;


    }
}
