package burakozenc.com.mp3playerapp.Model;

import java.io.Serializable;

public class Album implements Serializable {
    private int albumId;
    private String albumAdi;
    private String albumAciklama;
    private int sanatciId;
    private String cikisTarihi;

    public Album() {
    }

    public Album(int albumId, String albumAdi, String albumAciklama, int sanatciId, String cikisTarihi) {
        this.albumId = albumId;
        this.albumAdi = albumAdi;
        this.albumAciklama = albumAciklama;
        this.sanatciId = sanatciId;
        this.cikisTarihi = cikisTarihi;
    }

    public int getAlbumId() {
        return albumId;
    }

    public void setAlbumId(int albumId) {
        this.albumId = albumId;
    }

    public String getAlbumAdi() {
        return albumAdi;
    }

    public void setAlbumAdi(String albumAdi) {
        this.albumAdi = albumAdi;
    }

    public String getAlbumAciklama() {
        return albumAciklama;
    }

    public void setAlbumAciklama(String albumAciklama) {
        this.albumAciklama = albumAciklama;
    }

    public int getSanatciId() {
        return sanatciId;
    }

    public void setSanatciId(int sanatciId) {
        this.sanatciId = sanatciId;
    }

    public String getCikisTarihi() {
        return cikisTarihi;
    }

    public void setCikisTarihi(String cikisTarihi) {
        this.cikisTarihi = cikisTarihi;
    }
}
