package com.example.lab08.otherapplicationwithintent;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btnCall;
    EditText etPhoneNumber;
    Button btnWeb;
    EditText etWeb;
    Button btnSms;
    EditText etSms;
    EditText etSmsicerik;
    Button btnMarket;
    Button btnMap;
    Button btnMail;
    EditText etKonu;
    EditText eticerik;
    EditText etMail;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnCall = findViewById(R.id.btnCall);
        etPhoneNumber = findViewById(R.id.etPhoneNumber);

        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_VIEW);
                Uri uri = Uri.parse("tel:"+etPhoneNumber.getText().toString());
                i.setData(uri);
                startActivity(i);
            }
        });


        btnWeb = findViewById(R.id.btnWeb);
        etWeb = findViewById(R.id.etWeb);

        btnWeb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_VIEW);
                Uri uri = Uri.parse("http://"+etWeb.getText().toString());
                i.setData(uri);
                startActivity(i);
            }
        });

        btnSms = findViewById(R.id.btnSms);
        etSms = findViewById(R.id.etSms);
        etSmsicerik = findViewById(R.id.etSmsicerik);

        btnSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_SENDTO);
                Uri uri = Uri.parse("sms:"+etSms.getText().toString());
                i.putExtra("sms_body",etSmsicerik.getText().toString());
                i.setData(uri);
                startActivity(i);
            }
        });
        /*
        btnMarket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try
                {
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse("market://details?id=com.viber.voip"));
                    startActivity(intent);
                }
                catch (Exception e)
                {
                    Toast.makeText(getApplicationContext(),"play store yok.",Toast.LENGTH_LONG).show();

                }
            }
        });


        btnMap = findViewById(R.id.btnMap);
        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse("geo:0,0?q=41.0085812,29.9802257 (AYASOFYA)")));
            }
        });
*/
        btnMail = findViewById(R.id.btnMail);
        etKonu = findViewById(R.id.etKonu);
        eticerik = findViewById(R.id.eticerik);
        etMail = findViewById(R.id.etMail);
        btnMail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/html");
                intent.putExtra(Intent.EXTRA_EMAIL,etMail.getText().toString());
                intent.putExtra(Intent.EXTRA_SUBJECT,eticerik.getText().toString());
                intent.putExtra(Intent.EXTRA_TEXT,etKonu.getText().toString());
                intent.putExtra(Intent.EXTRA_STREAM, Uri.parse("content://epostaya/ekleyeceginiz/dosyanin/adresi"));
                startActivity(Intent.createChooser(intent,"Choose app"));



            }
        });

    }
}
